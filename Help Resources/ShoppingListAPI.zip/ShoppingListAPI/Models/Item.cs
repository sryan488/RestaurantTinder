namespace ShoppingListAPI.Models
{
    public class Item
    {
        public int Id {get;set;}
        public string name {get;set;}
        public bool completed {get;set;}
        
    }
}